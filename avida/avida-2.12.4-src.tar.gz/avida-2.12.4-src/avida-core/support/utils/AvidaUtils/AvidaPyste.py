#! /usr/bin/python

import os
import site

from Pyste import pyste
pyste.main()

